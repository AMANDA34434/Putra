"use client"

import AdminPage from "../pages/admin"

export default function SyntheticV0PageForDeployment() {
  return <AdminPage />
}