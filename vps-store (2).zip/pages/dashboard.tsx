"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { useRouter } from "next/router"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Server, Wallet, ShoppingCart, LogOut, CreditCard, ExternalLink, Copy, CheckCircle } from "lucide-react"
import { ThemeToggle } from "@/components/theme-toggle"

interface User {
  id: number
  username: string
  email: string
  fullName: string
  balance: number
  role: string
}

interface VPSPanel {
  id: number
  userId: number
  productName: string
  domain: string
  username: string
  password: string
  apiKey: string
  status: string
  createdAt: string
}

export default function DashboardPage() {
  const [user, setUser] = useState<User | null>(null)
  const [topupAmount, setTopupAmount] = useState("")
  const [vpsPanels, setVpsPanels] = useState<VPSPanel[]>([])
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState("")
  const router = useRouter()

  useEffect(() => {
    const userData = localStorage.getItem("user")
    if (!userData) {
      router.push("/login")
      return
    }

    const parsedUser = JSON.parse(userData)
    if (!parsedUser.isLoggedIn) {
      router.push("/login")
      return
    }

    setUser(parsedUser)
    loadVPSPanels(parsedUser.id)
  }, [router])

  const loadVPSPanels = (userId: number) => {
    const panels = JSON.parse(localStorage.getItem("vpsPanels") || "[]")
    const userPanels = panels.filter((panel: VPSPanel) => panel.userId === userId)
    setVpsPanels(userPanels)
  }

  const handleLogout = () => {
    localStorage.removeItem("user")
    router.push("/")
  }

  const handleTopup = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user) return

    setLoading(true)
    const amount = Number.parseInt(topupAmount)

    if (amount < 10000) {
      setMessage("Minimal top up Rp 10.000")
      setLoading(false)
      return
    }

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Create top up request
    const topupRequests = JSON.parse(localStorage.getItem("topupRequests") || "[]")
    const newRequest = {
      id: Date.now(),
      userId: user.id,
      amount: amount,
      status: "pending",
      createdAt: new Date().toISOString(),
    }

    topupRequests.push(newRequest)
    localStorage.setItem("topupRequests", JSON.stringify(topupRequests))

    setMessage("Permintaan top up berhasil dikirim. Menunggu konfirmasi admin.")
    setTopupAmount("")
    setLoading(false)
  }

  const buyVPS = async (productId: number, productName: string, price: number) => {
    if (!user) return

    if (user.balance < price) {
      setMessage("Saldo tidak mencukupi. Silakan top up terlebih dahulu.")
      return
    }

    setLoading(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 2000))

    // Generate VPS credentials
    const vpsCredentials = {
      id: Date.now(),
      userId: user.id,
      productName: productName,
      domain: "https://natan-and-friends.zebubhost.cloud",
      username: `user_${Date.now()}`,
      password: `pass_${Math.random().toString(36).substring(7)}`,
      apiKey: productName.includes("Basic")
        ? "ptla_2a8RQiWFCyd09Zc92KcyU3c7ZWdRPqoL11T25D0f2kO"
        : productName.includes("Pro")
          ? "ptlc_7s6A1btJakXuNbHOxwplEzWoaepUXNZrSJeIcQpsTSt"
          : "ptla_2a8RQiWFCyd09Zc92KcyU3c7ZWdRPqoL11T25D0f2kO",
      status: "active",
      createdAt: new Date().toISOString(),
    }

    // Save VPS panel
    const panels = JSON.parse(localStorage.getItem("vpsPanels") || "[]")
    panels.push(vpsCredentials)
    localStorage.setItem("vpsPanels", JSON.stringify(panels))

    // Update user balance
    const updatedUser = { ...user, balance: user.balance - price }
    setUser(updatedUser)
    localStorage.setItem("user", JSON.stringify({ ...updatedUser, isLoggedIn: true }))

    // Update users in storage
    const users = JSON.parse(localStorage.getItem("users") || "[]")
    const userIndex = users.findIndex((u: User) => u.id === user.id)
    if (userIndex !== -1) {
      users[userIndex] = updatedUser
      localStorage.setItem("users", JSON.stringify(users))
    }

    loadVPSPanels(user.id)
    setMessage("VPS Panel berhasil dibeli! Silakan cek tab 'Panel Saya'.")
    setLoading(false)
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    setMessage("Berhasil disalin ke clipboard!")
    setTimeout(() => setMessage(""), 3000)
  }

  const products = [
    {
      id: 1,
      name: "VPS Basic Panel",
      description: "Panel VPS dengan spesifikasi dasar untuk pemula",
      price: 50000,
      features: ["1 CPU Core", "1GB RAM", "20GB Storage", "PLTA Access"],
    },
    {
      id: 2,
      name: "VPS Pro Panel",
      description: "Panel VPS dengan spesifikasi menengah untuk bisnis",
      price: 100000,
      features: ["2 CPU Core", "2GB RAM", "50GB Storage", "PLTA + PLTC Access"],
    },
    {
      id: 3,
      name: "VPS Enterprise Panel",
      description: "Panel VPS dengan spesifikasi tinggi untuk enterprise",
      price: 200000,
      features: ["4 CPU Core", "4GB RAM", "100GB Storage", "Full API Access", "Priority Support"],
    },
  ]

  if (!user) {
    return <div>Loading...</div>
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted">
      {/* Header */}
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Server className="h-8 w-8 text-primary" />
            <h1 className="text-2xl font-bold">VPS Store</h1>
          </div>

          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2 bg-muted px-3 py-2 rounded-lg">
              <Wallet className="h-4 w-4" />
              <span className="font-medium">Rp {user.balance.toLocaleString("id-ID")}</span>
            </div>
            <span className="text-sm text-muted-foreground">Halo, {user.fullName}</span>
            <ThemeToggle />
            <Button variant="outline" onClick={handleLogout}>
              <LogOut className="h-4 w-4 mr-2" />
              Keluar
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {message && (
          <Alert className="mb-6">
            <CheckCircle className="h-4 w-4" />
            <AlertDescription>{message}</AlertDescription>
          </Alert>
        )}

        <Tabs defaultValue="dashboard" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="topup">Top Up</TabsTrigger>
            <TabsTrigger value="shop">Beli VPS</TabsTrigger>
            <TabsTrigger value="panels">Panel Saya</TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="space-y-6">
            <div className="grid md:grid-cols-3 gap-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Saldo</CardTitle>
                  <Wallet className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">Rp {user.balance.toLocaleString("id-ID")}</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Panel Aktif</CardTitle>
                  <Server className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{vpsPanels.length}</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Status</CardTitle>
                  <CheckCircle className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">Aktif</div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Selamat Datang, {user.fullName}!</CardTitle>
                <CardDescription>Kelola VPS panel Anda dengan mudah melalui dashboard ini.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <p className="text-muted-foreground">
                    Anda dapat melakukan top up saldo, membeli VPS panel baru, dan mengelola panel yang sudah ada.
                  </p>
                  <div className="flex space-x-4">
                    <Button onClick={() => document.querySelector('[value="topup"]')?.click()}>
                      <CreditCard className="h-4 w-4 mr-2" />
                      Top Up Saldo
                    </Button>
                    <Button variant="outline" onClick={() => document.querySelector('[value="shop"]')?.click()}>
                      <ShoppingCart className="h-4 w-4 mr-2" />
                      Beli VPS Panel
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="topup" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Top Up Saldo</CardTitle>
                <CardDescription>
                  Isi saldo Anda untuk membeli VPS panel. Admin akan mengkonfirmasi pembayaran Anda.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleTopup} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="amount">Jumlah Top Up (Rp)</Label>
                    <Input
                      id="amount"
                      type="number"
                      placeholder="Minimal Rp 10.000"
                      value={topupAmount}
                      onChange={(e) => setTopupAmount(e.target.value)}
                      min="10000"
                      required
                    />
                  </div>

                  <div className="bg-muted p-4 rounded-lg">
                    <h4 className="font-medium mb-2">Cara Top Up:</h4>
                    <ol className="text-sm text-muted-foreground space-y-1">
                      <li>1. Masukkan jumlah yang ingin di-top up</li>
                      <li>2. Klik tombol "Kirim Permintaan"</li>
                      <li>3. Admin akan mengkonfirmasi dan saldo akan masuk otomatis</li>
                    </ol>
                  </div>

                  <Button type="submit" disabled={loading}>
                    {loading ? "Memproses..." : "Kirim Permintaan"}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="shop" className="space-y-6">
            <div className="grid md:grid-cols-3 gap-6">
              {products.map((product) => (
                <Card key={product.id}>
                  <CardHeader>
                    <CardTitle className="text-xl">{product.name}</CardTitle>
                    <CardDescription>{product.description}</CardDescription>
                    <div className="text-3xl font-bold text-primary">Rp {product.price.toLocaleString("id-ID")}</div>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2 mb-6">
                      {product.features.map((feature, index) => (
                        <li key={index} className="flex items-center">
                          <div className="w-2 h-2 bg-primary rounded-full mr-3" />
                          {feature}
                        </li>
                      ))}
                    </ul>
                    <Button
                      className="w-full"
                      onClick={() => buyVPS(product.id, product.name, product.price)}
                      disabled={loading || user.balance < product.price}
                    >
                      {user.balance < product.price ? "Saldo Tidak Cukup" : "Beli Sekarang"}
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="panels" className="space-y-6">
            {vpsPanels.length === 0 ? (
              <Card>
                <CardContent className="text-center py-12">
                  <Server className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-medium mb-2">Belum Ada Panel</h3>
                  <p className="text-muted-foreground mb-4">
                    Anda belum memiliki VPS panel. Beli panel pertama Anda sekarang!
                  </p>
                  <Button onClick={() => document.querySelector('[value="shop"]')?.click()}>
                    <ShoppingCart className="h-4 w-4 mr-2" />
                    Beli VPS Panel
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-6">
                {vpsPanels.map((panel) => (
                  <Card key={panel.id}>
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle>{panel.productName}</CardTitle>
                        <Badge variant="default">{panel.status === "active" ? "Aktif" : "Tidak Aktif"}</Badge>
                      </div>
                      <CardDescription>
                        Dibuat pada {new Date(panel.createdAt).toLocaleDateString("id-ID")}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label>Domain</Label>
                          <div className="flex items-center space-x-2">
                            <Input value={panel.domain} readOnly />
                            <Button size="sm" variant="outline" onClick={() => copyToClipboard(panel.domain)}>
                              <Copy className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="outline" onClick={() => window.open(panel.domain, "_blank")}>
                              <ExternalLink className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>

                        <div className="space-y-2">
                          <Label>Username</Label>
                          <div className="flex items-center space-x-2">
                            <Input value={panel.username} readOnly />
                            <Button size="sm" variant="outline" onClick={() => copyToClipboard(panel.username)}>
                              <Copy className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>

                        <div className="space-y-2">
                          <Label>Password</Label>
                          <div className="flex items-center space-x-2">
                            <Input value={panel.password} readOnly type="password" />
                            <Button size="sm" variant="outline" onClick={() => copyToClipboard(panel.password)}>
                              <Copy className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>

                        <div className="space-y-2">
                          <Label>API Key</Label>
                          <div className="flex items-center space-x-2">
                            <Input value={panel.apiKey} readOnly type="password" />
                            <Button size="sm" variant="outline" onClick={() => copyToClipboard(panel.apiKey)}>
                              <Copy className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </div>

                      <div className="flex space-x-2">
                        <Button onClick={() => window.open(panel.domain, "_blank")} className="flex-1">
                          <ExternalLink className="h-4 w-4 mr-2" />
                          Buka Panel
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
