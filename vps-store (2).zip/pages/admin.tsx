"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/router"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Server, Users, Wallet, LogOut, CheckCircle, XCircle, Edit, Trash2, Plus, Music } from "lucide-react"
import { ThemeToggle } from "@/components/theme-toggle"

interface User {
  id: number
  username: string
  email: string
  fullName: string
  balance: number
  role: string
  createdAt: string
}

interface TopupRequest {
  id: number
  userId: number
  amount: number
  status: string
  createdAt: string
}

interface Product {
  id: number
  name: string
  description: string
  price: number
  features: string[]
  status: string
}

export default function AdminPage() {
  const [users, setUsers] = useState<User[]>([])
  const [topupRequests, setTopupRequests] = useState<TopupRequest[]>([])
  const [products, setProducts] = useState<Product[]>([])
  const [message, setMessage] = useState("")
  const [editingProduct, setEditingProduct] = useState<Product | null>(null)
  const [newProduct, setNewProduct] = useState({
    name: "",
    description: "",
    price: 0,
    features: [""],
    status: "active",
  })
  const router = useRouter()

  useEffect(() => {
    const userData = localStorage.getItem("user")
    if (!userData) {
      router.push("/login")
      return
    }

    const parsedUser = JSON.parse(userData)
    if (!parsedUser.isLoggedIn || parsedUser.role !== "admin") {
      router.push("/login")
      return
    }

    loadData()
  }, [router])

  const loadData = () => {
    // Load users
    const usersData = JSON.parse(localStorage.getItem("users") || "[]")
    setUsers(usersData)

    // Load topup requests
    const topupData = JSON.parse(localStorage.getItem("topupRequests") || "[]")
    setTopupRequests(topupData)

    // Load products
    const productsData = JSON.parse(
      localStorage.getItem("products") ||
        JSON.stringify([
          {
            id: 1,
            name: "VPS Basic Panel",
            description: "Panel VPS dengan spesifikasi dasar untuk pemula",
            price: 50000,
            features: ["1 CPU Core", "1GB RAM", "20GB Storage", "PLTA Access"],
            status: "active",
          },
          {
            id: 2,
            name: "VPS Pro Panel",
            description: "Panel VPS dengan spesifikasi menengah untuk bisnis",
            price: 100000,
            features: ["2 CPU Core", "2GB RAM", "50GB Storage", "PLTA + PLTC Access"],
            status: "active",
          },
          {
            id: 3,
            name: "VPS Enterprise Panel",
            description: "Panel VPS dengan spesifikasi tinggi untuk enterprise",
            price: 200000,
            features: ["4 CPU Core", "4GB RAM", "100GB Storage", "Full API Access", "Priority Support"],
            status: "active",
          },
        ]),
    )
    setProducts(productsData)
  }

  const handleLogout = () => {
    localStorage.removeItem("user")
    router.push("/")
  }

  const approveTopup = (requestId: number, userId: number, amount: number) => {
    // Update topup request status
    const updatedRequests = topupRequests.map((req) => (req.id === requestId ? { ...req, status: "approved" } : req))
    setTopupRequests(updatedRequests)
    localStorage.setItem("topupRequests", JSON.stringify(updatedRequests))

    // Update user balance
    const updatedUsers = users.map((user) => (user.id === userId ? { ...user, balance: user.balance + amount } : user))
    setUsers(updatedUsers)
    localStorage.setItem("users", JSON.stringify(updatedUsers))

    setMessage(`Top up sebesar Rp ${amount.toLocaleString("id-ID")} berhasil disetujui`)
  }

  const rejectTopup = (requestId: number) => {
    const updatedRequests = topupRequests.map((req) => (req.id === requestId ? { ...req, status: "rejected" } : req))
    setTopupRequests(updatedRequests)
    localStorage.setItem("topupRequests", JSON.stringify(updatedRequests))

    setMessage("Permintaan top up ditolak")
  }

  const addProduct = () => {
    if (!newProduct.name || !newProduct.description || newProduct.price <= 0) {
      setMessage("Mohon lengkapi semua field produk")
      return
    }

    const product = {
      ...newProduct,
      id: Date.now(),
      features: newProduct.features.filter((f) => f.trim() !== ""),
    }

    const updatedProducts = [...products, product]
    setProducts(updatedProducts)
    localStorage.setItem("products", JSON.stringify(updatedProducts))

    setNewProduct({
      name: "",
      description: "",
      price: 0,
      features: [""],
      status: "active",
    })

    setMessage("Produk berhasil ditambahkan")
  }

  const updateProduct = () => {
    if (!editingProduct) return

    const updatedProducts = products.map((p) => (p.id === editingProduct.id ? editingProduct : p))
    setProducts(updatedProducts)
    localStorage.setItem("products", JSON.stringify(updatedProducts))
    setEditingProduct(null)
    setMessage("Produk berhasil diupdate")
  }

  const deleteProduct = (productId: number) => {
    const updatedProducts = products.filter((p) => p.id !== productId)
    setProducts(updatedProducts)
    localStorage.setItem("products", JSON.stringify(updatedProducts))
    setMessage("Produk berhasil dihapus")
  }

  const getUserById = (userId: number) => {
    return users.find((user) => user.id === userId)
  }

  const pendingTopups = topupRequests.filter((req) => req.status === "pending")
  const totalUsers = users.length
  const totalRevenue = topupRequests
    .filter((req) => req.status === "approved")
    .reduce((sum, req) => sum + req.amount, 0)

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted">
      {/* Header */}
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Server className="h-8 w-8 text-primary" />
            <h1 className="text-2xl font-bold">Admin Panel</h1>
          </div>

          <div className="flex items-center space-x-4">
            <Badge variant="secondary">Admin</Badge>
            <ThemeToggle />
            <Button variant="outline" onClick={handleLogout}>
              <LogOut className="h-4 w-4 mr-2" />
              Keluar
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {message && (
          <Alert className="mb-6">
            <CheckCircle className="h-4 w-4" />
            <AlertDescription>{message}</AlertDescription>
          </Alert>
        )}

        <Tabs defaultValue="dashboard" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="users">Users</TabsTrigger>
            <TabsTrigger value="topup">Top Up</TabsTrigger>
            <TabsTrigger value="products">Produk</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="space-y-6">
            <div className="grid md:grid-cols-4 gap-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Users</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{totalUsers}</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Pending Top Up</CardTitle>
                  <Wallet className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{pendingTopups.length}</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
                  <Wallet className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">Rp {totalRevenue.toLocaleString("id-ID")}</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Produk Aktif</CardTitle>
                  <Server className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{products.filter((p) => p.status === "active").length}</div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Selamat Datang, Admin!</CardTitle>
                <CardDescription>Kelola sistem VPS Store melalui panel admin ini.</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Anda dapat mengelola users, menyetujui permintaan top up, mengatur produk, dan konfigurasi sistem.
                </p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="users" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Manajemen Users</CardTitle>
                <CardDescription>Daftar semua users yang terdaftar di sistem</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Username</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Nama Lengkap</TableHead>
                      <TableHead>Saldo</TableHead>
                      <TableHead>Tanggal Daftar</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {users.map((user) => (
                      <TableRow key={user.id}>
                        <TableCell className="font-medium">{user.username}</TableCell>
                        <TableCell>{user.email}</TableCell>
                        <TableCell>{user.fullName}</TableCell>
                        <TableCell>Rp {user.balance.toLocaleString("id-ID")}</TableCell>
                        <TableCell>{new Date(user.createdAt).toLocaleDateString("id-ID")}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="topup" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Permintaan Top Up</CardTitle>
                <CardDescription>Setujui atau tolak permintaan top up dari users</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>User</TableHead>
                      <TableHead>Jumlah</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Tanggal</TableHead>
                      <TableHead>Aksi</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {topupRequests.map((request) => {
                      const user = getUserById(request.userId)
                      return (
                        <TableRow key={request.id}>
                          <TableCell className="font-medium">
                            {user?.fullName} ({user?.username})
                          </TableCell>
                          <TableCell>Rp {request.amount.toLocaleString("id-ID")}</TableCell>
                          <TableCell>
                            <Badge
                              variant={
                                request.status === "pending"
                                  ? "secondary"
                                  : request.status === "approved"
                                    ? "default"
                                    : "destructive"
                              }
                            >
                              {request.status === "pending"
                                ? "Menunggu"
                                : request.status === "approved"
                                  ? "Disetujui"
                                  : "Ditolak"}
                            </Badge>
                          </TableCell>
                          <TableCell>{new Date(request.createdAt).toLocaleDateString("id-ID")}</TableCell>
                          <TableCell>
                            {request.status === "pending" && (
                              <div className="flex space-x-2">
                                <Button
                                  size="sm"
                                  onClick={() => approveTopup(request.id, request.userId, request.amount)}
                                >
                                  <CheckCircle className="h-4 w-4 mr-1" />
                                  Setuju
                                </Button>
                                <Button size="sm" variant="destructive" onClick={() => rejectTopup(request.id)}>
                                  <XCircle className="h-4 w-4 mr-1" />
                                  Tolak
                                </Button>
                              </div>
                            )}
                          </TableCell>
                        </TableRow>
                      )
                    })}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="products" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Manajemen Produk</CardTitle>
                <CardDescription>Kelola produk VPS panel yang tersedia</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Add New Product */}
                <div className="border rounded-lg p-4">
                  <h4 className="font-medium mb-4">Tambah Produk Baru</h4>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Nama Produk</Label>
                      <Input
                        value={newProduct.name}
                        onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
                        placeholder="Nama produk"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Harga (Rp)</Label>
                      <Input
                        type="number"
                        value={newProduct.price}
                        onChange={(e) => setNewProduct({ ...newProduct, price: Number.parseInt(e.target.value) || 0 })}
                        placeholder="Harga produk"
                      />
                    </div>
                    <div className="space-y-2 md:col-span-2">
                      <Label>Deskripsi</Label>
                      <Textarea
                        value={newProduct.description}
                        onChange={(e) => setNewProduct({ ...newProduct, description: e.target.value })}
                        placeholder="Deskripsi produk"
                      />
                    </div>
                    <div className="space-y-2 md:col-span-2">
                      <Label>Fitur (satu per baris)</Label>
                      {newProduct.features.map((feature, index) => (
                        <div key={index} className="flex space-x-2">
                          <Input
                            value={feature}
                            onChange={(e) => {
                              const updatedFeatures = [...newProduct.features]
                              updatedFeatures[index] = e.target.value
                              setNewProduct({ ...newProduct, features: updatedFeatures })
                            }}
                            placeholder="Fitur produk"
                          />
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              const updatedFeatures = newProduct.features.filter((_, i) => i !== index)
                              setNewProduct({ ...newProduct, features: updatedFeatures })
                            }}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => setNewProduct({ ...newProduct, features: [...newProduct.features, ""] })}
                      >
                        <Plus className="h-4 w-4 mr-2" />
                        Tambah Fitur
                      </Button>
                    </div>
                  </div>
                  <Button onClick={addProduct} className="mt-4">
                    <Plus className="h-4 w-4 mr-2" />
                    Tambah Produk
                  </Button>
                </div>

                {/* Existing Products */}
                <div className="space-y-4">
                  <h4 className="font-medium">Produk Existing</h4>
                  {products.map((product) => (
                    <Card key={product.id}>
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <CardTitle className="text-lg">{product.name}</CardTitle>
                          <div className="flex items-center space-x-2">
                            <Badge variant={product.status === "active" ? "default" : "secondary"}>
                              {product.status === "active" ? "Aktif" : "Tidak Aktif"}
                            </Badge>
                            <Button size="sm" variant="outline" onClick={() => setEditingProduct(product)}>
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="destructive" onClick={() => deleteProduct(product.id)}>
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                        <CardDescription>{product.description}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center justify-between">
                          <div className="text-2xl font-bold text-primary">
                            Rp {product.price.toLocaleString("id-ID")}
                          </div>
                          <div className="text-sm text-muted-foreground">{product.features.length} fitur</div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>

                {/* Edit Product Modal */}
                {editingProduct && (
                  <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
                    <Card className="w-full max-w-2xl">
                      <CardHeader>
                        <CardTitle>Edit Produk</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="grid md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label>Nama Produk</Label>
                            <Input
                              value={editingProduct.name}
                              onChange={(e) => setEditingProduct({ ...editingProduct, name: e.target.value })}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>Harga (Rp)</Label>
                            <Input
                              type="number"
                              value={editingProduct.price}
                              onChange={(e) =>
                                setEditingProduct({ ...editingProduct, price: Number.parseInt(e.target.value) || 0 })
                              }
                            />
                          </div>
                          <div className="space-y-2 md:col-span-2">
                            <Label>Deskripsi</Label>
                            <Textarea
                              value={editingProduct.description}
                              onChange={(e) => setEditingProduct({ ...editingProduct, description: e.target.value })}
                            />
                          </div>
                          <div className="space-y-2 md:col-span-2">
                            <Label>Fitur</Label>
                            {editingProduct.features.map((feature, index) => (
                              <div key={index} className="flex space-x-2">
                                <Input
                                  value={feature}
                                  onChange={(e) => {
                                    const updatedFeatures = [...editingProduct.features]
                                    updatedFeatures[index] = e.target.value
                                    setEditingProduct({ ...editingProduct, features: updatedFeatures })
                                  }}
                                />
                                <Button
                                  type="button"
                                  variant="outline"
                                  size="sm"
                                  onClick={() => {
                                    const updatedFeatures = editingProduct.features.filter((_, i) => i !== index)
                                    setEditingProduct({ ...editingProduct, features: updatedFeatures })
                                  }}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            ))}
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              onClick={() =>
                                setEditingProduct({ ...editingProduct, features: [...editingProduct.features, ""] })
                              }
                            >
                              <Plus className="h-4 w-4 mr-2" />
                              Tambah Fitur
                            </Button>
                          </div>
                        </div>
                        <div className="flex justify-end space-x-2">
                          <Button variant="outline" onClick={() => setEditingProduct(null)}>
                            Batal
                          </Button>
                          <Button onClick={updateProduct}>Update Produk</Button>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Pengaturan Sistem</CardTitle>
                <CardDescription>Konfigurasi sistem dan pengaturan lainnya</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <h4 className="font-medium">Domain VPS</h4>
                      <p className="text-sm text-muted-foreground">https://natan-and-friends.zebubhost.cloud</p>
                    </div>
                    <Button variant="outline" size="sm">
                      <Edit className="h-4 w-4 mr-2" />
                      Edit
                    </Button>
                  </div>

                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <h4 className="font-medium">API Key PLTA</h4>
                      <p className="text-sm text-muted-foreground">ptla_2a8RQiWFCyd09Zc92KcyU3c7ZWdRPqoL11T25D0f2kO</p>
                    </div>
                    <Button variant="outline" size="sm">
                      <Edit className="h-4 w-4 mr-2" />
                      Edit
                    </Button>
                  </div>

                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <h4 className="font-medium">API Key PLTC</h4>
                      <p className="text-sm text-muted-foreground">ptlc_7s6A1btJakXuNbHOxwplEzWoaepUXNZrSJeIcQpsTSt</p>
                    </div>
                    <Button variant="outline" size="sm">
                      <Edit className="h-4 w-4 mr-2" />
                      Edit
                    </Button>
                  </div>

                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <h4 className="font-medium">Background Music</h4>
                      <p className="text-sm text-muted-foreground">O, Tuan Penciptaannya - Feast</p>
                    </div>
                    <Button variant="outline" size="sm">
                      <Music className="h-4 w-4 mr-2" />
                      Ganti Music
                    </Button>
                  </div>
                </div>

                <div className="border-t pt-6">
                  <h4 className="font-medium mb-4">Statistik Sistem</h4>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="p-4 bg-muted rounded-lg">
                      <div className="text-2xl font-bold">{users.length}</div>
                      <div className="text-sm text-muted-foreground">Total Users Terdaftar</div>
                    </div>
                    <div className="p-4 bg-muted rounded-lg">
                      <div className="text-2xl font-bold">
                        {topupRequests.filter((r) => r.status === "approved").length}
                      </div>
                      <div className="text-sm text-muted-foreground">Top Up Disetujui</div>
                    </div>
                    <div className="p-4 bg-muted rounded-lg">
                      <div className="text-2xl font-bold">Rp {totalRevenue.toLocaleString("id-ID")}</div>
                      <div className="text-sm text-muted-foreground">Total Revenue</div>
                    </div>
                    <div className="p-4 bg-muted rounded-lg">
                      <div className="text-2xl font-bold">{products.filter((p) => p.status === "active").length}</div>
                      <div className="text-sm text-muted-foreground">Produk Aktif</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
